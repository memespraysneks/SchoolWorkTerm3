#Color palette
https://colors.dopely.top/palette-generator/JdtkzBXupm5
