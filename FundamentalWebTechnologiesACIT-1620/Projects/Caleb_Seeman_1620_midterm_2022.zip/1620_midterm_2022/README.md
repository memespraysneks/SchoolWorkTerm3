# 1620_midterm_2022

Starter files for 1620 midterm 2022

## Color Palette for midterm

[Color Palette](https://colors.dopely.top/palette-generator/YPeF62Xu2uX)
