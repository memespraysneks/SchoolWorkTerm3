# 1620_w8_w22

Week 8 starter files 1620

colors from the [rose pine theme](https://rosepinetheme.com/)
