# Color Palette for my portfolio 

#FFEDF0, #041E27, #CAA0E8

## link to my color palette

[my color palette](https://colors.dopely.top/palette-generator/yzdL2UyeN6z)

## image of my color palette

![my color palette](images/palette.png)