install.packages('magick')

img <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page1.png')
plot(img) # or print(img)

img2 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page2.png')
plot(img2) # or print(img)

img3 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page3.png')
plot(img3) # or print(img)

img4 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page4.png')
plot(img4) # or print(img)

img5 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page5.png')
plot(img5) # or print(img)

img6 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page6.png')
plot(img6) # or print(img)

img7 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page7.png')
plot(img7) # or print(img)

img8 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page8.png')
plot(img8) # or print(img)

img9 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page9.png')
plot(img9) # or print(img)

img10 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page10.png')
plot(img10) # or print(img)

img11 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page11.png')
plot(img11) # or print(img)

img12 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page12.png')
plot(img12) # or print(img)

img13 <- magick::image_read('/Users/caleb/Documents/SchoolWork/Statistics for IT MATH-1350/Page13.png')
plot(img13) # or print(img)